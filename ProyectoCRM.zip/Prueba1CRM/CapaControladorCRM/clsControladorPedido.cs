﻿using CapaModeloCRM;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Odbc;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaControladorCRM
{
    public class clsControladorPedido
    {
        clsModeloPedido sn = new clsModeloPedido();
        int total;
        int prueb;
        String ape = "";

        public int prueba(int prue)
        {
            clsConexion con = new clsConexion();
            string sql = "SELECT pk_id_pedido_encabezado FROM pedido_encabezado ORDER BY pk_id_pedido_encabezado DESC LIMIT 1";
            OdbcCommand command = new OdbcCommand(sql, con.conexion());
            OdbcDataReader read;
            read = command.ExecuteReader();
            while (read.Read())
            {
                ape = read.GetString(0);
            }
            prueb = Convert.ToInt32(ape.ToString());
            return prueb;
        }

        //----------------------------------------------- Metodos para llenar Combobox de Producto ----------------------------------------
        public string[] items(string tabla, string campo1, string campo2)
        {
            string[] Items = sn.llenarCmb(tabla, campo1, campo2);

            return Items;
        }

        public DataTable enviar(string tabla, string campo1, string campo2)
        {
            var dt1 = sn.obtener(tabla, campo1, campo2);

            return dt1;
        }
        //------------------------------------------------- Metodos Para llenar Combobox de Fabrica -------------------------------------
        public string[] itemsFabrica(string tabla, string campo1, string campo2)
        {
            string[] Items = sn.llenarCmbFabrica(tabla, campo1, campo2);

            return Items;
        }

        public DataTable enviarFabrica(string tabla, string campo1, string campo2)
        {
            var dt1 = sn.obtenerFabrica(tabla, campo1, campo2);

            return dt1;
        }

        //***************************************** Metodo que pasa los valores para la insercion de pedido ****************************
        public void insertPedido(int fab, string fec, double tot)
        {
            clsModeloPedido mp = new clsModeloPedido();
            mp.insertarPedido(fab, fec, tot);
        }

        //***************************************** Metodo que pasa datos para su insercion **********************************
        public void insertdetalle(int prod, int cantidad, double prize, double sub)
        {
            clsModeloPedido mm = new clsModeloPedido();
            mm.insertarDetallePedido(prod, cantidad, prize, sub);
        }

    }
}
