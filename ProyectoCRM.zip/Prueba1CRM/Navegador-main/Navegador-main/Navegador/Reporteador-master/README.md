# Reporteador
Objeto Común Reporteador, para Proyecto ERP
