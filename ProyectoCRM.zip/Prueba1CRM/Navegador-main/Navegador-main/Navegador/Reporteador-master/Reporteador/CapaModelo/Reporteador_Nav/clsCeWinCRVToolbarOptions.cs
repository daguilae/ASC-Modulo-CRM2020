﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaModeloReporteador.Reporteador_Nav
{
    public enum clsCeWinCRVToolbarOptions
    {
        Page_Navigation_Button,
        Go_to_Page_Button,
        Close_View_Button,
        Print_Button,
        Refresh_Button,
        Export_Button,
        Group_Tree_Button,
        Zoom_Button,
        Search_Button
    }
}
