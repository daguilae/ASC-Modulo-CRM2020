﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaVista
{
    public static class clsDatoConsulta
    {
        public static string consulta;
    }
}
