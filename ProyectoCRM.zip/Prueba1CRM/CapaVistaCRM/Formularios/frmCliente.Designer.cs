﻿namespace CapaVistaCRM
{
    partial class frmCliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.navegador1 = new CapaVistaNavegador.Navegador();
            this.txtIdCliente = new System.Windows.Forms.TextBox();
            this.txtNitCliente = new System.Windows.Forms.TextBox();
            this.txtApellidoCliente = new System.Windows.Forms.TextBox();
            this.txtNumeroTel = new System.Windows.Forms.TextBox();
            this.txtCorreoCliente = new System.Windows.Forms.TextBox();
            this.txtDireccionCliente = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.txtNombreCliente = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.lblCodCliente = new System.Windows.Forms.Label();
            this.lblNitCliente = new System.Windows.Forms.Label();
            this.lblFechaNacimiento = new System.Windows.Forms.Label();
            this.lblNombreCliente = new System.Windows.Forms.Label();
            this.lblApellidoCliente = new System.Windows.Forms.Label();
            this.lblNumTelefono = new System.Windows.Forms.Label();
            this.lblEstado = new System.Windows.Forms.Label();
            this.lblCorreoCliente = new System.Windows.Forms.Label();
            this.lblDireccionCliente = new System.Windows.Forms.Label();
            this.tltNit = new System.Windows.Forms.ToolTip(this.components);
            this.tltCorreo = new System.Windows.Forms.ToolTip(this.components);
            this.tltDireccion = new System.Windows.Forms.ToolTip(this.components);
            this.lblManteCliente = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // navegador1
            // 
            this.navegador1.BackColor = System.Drawing.Color.Transparent;
            this.navegador1.Location = new System.Drawing.Point(13, 13);
            this.navegador1.Margin = new System.Windows.Forms.Padding(4);
            this.navegador1.Name = "navegador1";
            this.navegador1.Size = new System.Drawing.Size(1412, 129);
            this.navegador1.TabIndex = 0;
            this.navegador1.Load += new System.EventHandler(this.navegador1_Load);
            // 
            // txtIdCliente
            // 
            this.txtIdCliente.Location = new System.Drawing.Point(132, 172);
            this.txtIdCliente.Name = "txtIdCliente";
            this.txtIdCliente.Size = new System.Drawing.Size(100, 22);
            this.txtIdCliente.TabIndex = 1;
            this.txtIdCliente.Tag = "pk_id_cliente";
            // 
            // txtNitCliente
            // 
            this.txtNitCliente.Location = new System.Drawing.Point(132, 215);
            this.txtNitCliente.Name = "txtNitCliente";
            this.txtNitCliente.Size = new System.Drawing.Size(186, 22);
            this.txtNitCliente.TabIndex = 2;
            this.txtNitCliente.Tag = "nit_cliente";
            this.txtNitCliente.TextChanged += new System.EventHandler(this.txtNitCliente_TextChanged);
            this.txtNitCliente.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNitCliente_KeyPress);
            // 
            // txtApellidoCliente
            // 
            this.txtApellidoCliente.Location = new System.Drawing.Point(132, 365);
            this.txtApellidoCliente.Name = "txtApellidoCliente";
            this.txtApellidoCliente.Size = new System.Drawing.Size(186, 22);
            this.txtApellidoCliente.TabIndex = 5;
            this.txtApellidoCliente.Tag = "apellido_cliente";
            this.txtApellidoCliente.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtApellidoCliente_KeyPress);
            // 
            // txtNumeroTel
            // 
            this.txtNumeroTel.Location = new System.Drawing.Point(132, 422);
            this.txtNumeroTel.Name = "txtNumeroTel";
            this.txtNumeroTel.Size = new System.Drawing.Size(186, 22);
            this.txtNumeroTel.TabIndex = 6;
            this.txtNumeroTel.Tag = "telefono";
            this.txtNumeroTel.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumeroTel_KeyPress);
            // 
            // txtCorreoCliente
            // 
            this.txtCorreoCliente.Location = new System.Drawing.Point(132, 525);
            this.txtCorreoCliente.Name = "txtCorreoCliente";
            this.txtCorreoCliente.Size = new System.Drawing.Size(186, 22);
            this.txtCorreoCliente.TabIndex = 8;
            this.txtCorreoCliente.Tag = "correo_cliente";
            // 
            // txtDireccionCliente
            // 
            this.txtDireccionCliente.Location = new System.Drawing.Point(132, 581);
            this.txtDireccionCliente.Name = "txtDireccionCliente";
            this.txtDireccionCliente.Size = new System.Drawing.Size(186, 22);
            this.txtDireccionCliente.TabIndex = 9;
            this.txtDireccionCliente.Tag = "direccion_cliente";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(468, 139);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(921, 455);
            this.dataGridView1.TabIndex = 10;
            // 
            // txtNombreCliente
            // 
            this.txtNombreCliente.Location = new System.Drawing.Point(132, 313);
            this.txtNombreCliente.Name = "txtNombreCliente";
            this.txtNombreCliente.Size = new System.Drawing.Size(186, 22);
            this.txtNombreCliente.TabIndex = 4;
            this.txtNombreCliente.Tag = "nombre_cliente";
            this.txtNombreCliente.TextChanged += new System.EventHandler(this.txtNombreCliente_TextChanged);
            this.txtNombreCliente.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNombreCliente_KeyPress);
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(378, 475);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(27, 22);
            this.textBox7.TabIndex = 7;
            this.textBox7.Tag = "estado";
            // 
            // lblCodCliente
            // 
            this.lblCodCliente.AutoSize = true;
            this.lblCodCliente.Font = new System.Drawing.Font("Rockwell Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCodCliente.Location = new System.Drawing.Point(13, 172);
            this.lblCodCliente.Name = "lblCodCliente";
            this.lblCodCliente.Size = new System.Drawing.Size(98, 22);
            this.lblCodCliente.TabIndex = 11;
            this.lblCodCliente.Text = "Codigo Cliente";
            // 
            // lblNitCliente
            // 
            this.lblNitCliente.AutoSize = true;
            this.lblNitCliente.Font = new System.Drawing.Font("Rockwell Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNitCliente.Location = new System.Drawing.Point(13, 215);
            this.lblNitCliente.Name = "lblNitCliente";
            this.lblNitCliente.Size = new System.Drawing.Size(76, 22);
            this.lblNitCliente.TabIndex = 12;
            this.lblNitCliente.Text = "Nit Cliente";
            // 
            // lblFechaNacimiento
            // 
            this.lblFechaNacimiento.AutoSize = true;
            this.lblFechaNacimiento.Font = new System.Drawing.Font("Rockwell Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFechaNacimiento.Location = new System.Drawing.Point(10, 265);
            this.lblFechaNacimiento.Name = "lblFechaNacimiento";
            this.lblFechaNacimiento.Size = new System.Drawing.Size(118, 22);
            this.lblFechaNacimiento.TabIndex = 13;
            this.lblFechaNacimiento.Text = "Fecha Nacimiento";
            // 
            // lblNombreCliente
            // 
            this.lblNombreCliente.AutoSize = true;
            this.lblNombreCliente.Font = new System.Drawing.Font("Rockwell Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombreCliente.Location = new System.Drawing.Point(10, 313);
            this.lblNombreCliente.Name = "lblNombreCliente";
            this.lblNombreCliente.Size = new System.Drawing.Size(103, 22);
            this.lblNombreCliente.TabIndex = 14;
            this.lblNombreCliente.Text = "Nombre Cliente";
            // 
            // lblApellidoCliente
            // 
            this.lblApellidoCliente.AutoSize = true;
            this.lblApellidoCliente.Font = new System.Drawing.Font("Rockwell Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblApellidoCliente.Location = new System.Drawing.Point(10, 365);
            this.lblApellidoCliente.Name = "lblApellidoCliente";
            this.lblApellidoCliente.Size = new System.Drawing.Size(107, 22);
            this.lblApellidoCliente.TabIndex = 15;
            this.lblApellidoCliente.Text = "Apellido Cliente";
            // 
            // lblNumTelefono
            // 
            this.lblNumTelefono.AutoSize = true;
            this.lblNumTelefono.Font = new System.Drawing.Font("Rockwell Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumTelefono.Location = new System.Drawing.Point(10, 422);
            this.lblNumTelefono.Name = "lblNumTelefono";
            this.lblNumTelefono.Size = new System.Drawing.Size(124, 22);
            this.lblNumTelefono.TabIndex = 16;
            this.lblNumTelefono.Text = "Numero Telefonico";
            // 
            // lblEstado
            // 
            this.lblEstado.AutoSize = true;
            this.lblEstado.Font = new System.Drawing.Font("Rockwell Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEstado.Location = new System.Drawing.Point(10, 475);
            this.lblEstado.Name = "lblEstado";
            this.lblEstado.Size = new System.Drawing.Size(50, 22);
            this.lblEstado.TabIndex = 17;
            this.lblEstado.Text = "Estado";
            // 
            // lblCorreoCliente
            // 
            this.lblCorreoCliente.AutoSize = true;
            this.lblCorreoCliente.Font = new System.Drawing.Font("Rockwell Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCorreoCliente.Location = new System.Drawing.Point(10, 525);
            this.lblCorreoCliente.Name = "lblCorreoCliente";
            this.lblCorreoCliente.Size = new System.Drawing.Size(97, 22);
            this.lblCorreoCliente.TabIndex = 18;
            this.lblCorreoCliente.Text = "Correo Cliente";
            // 
            // lblDireccionCliente
            // 
            this.lblDireccionCliente.AutoSize = true;
            this.lblDireccionCliente.Font = new System.Drawing.Font("Rockwell Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDireccionCliente.Location = new System.Drawing.Point(10, 581);
            this.lblDireccionCliente.Name = "lblDireccionCliente";
            this.lblDireccionCliente.Size = new System.Drawing.Size(114, 22);
            this.lblDireccionCliente.TabIndex = 19;
            this.lblDireccionCliente.Text = "Direccion Cliente";
            // 
            // tltNit
            // 
            this.tltNit.AutoPopDelay = 5000;
            this.tltNit.InitialDelay = 200;
            this.tltNit.IsBalloon = true;
            this.tltNit.ReshowDelay = 100;
            this.tltNit.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.tltNit.ToolTipTitle = "Ingrese Nit Sin Guion";
            // 
            // tltCorreo
            // 
            this.tltCorreo.AutoPopDelay = 5000;
            this.tltCorreo.InitialDelay = 200;
            this.tltCorreo.IsBalloon = true;
            this.tltCorreo.ReshowDelay = 100;
            this.tltCorreo.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.tltCorreo.ToolTipTitle = "Correo Electronico de Cliente";
            // 
            // tltDireccion
            // 
            this.tltDireccion.AutoPopDelay = 5000;
            this.tltDireccion.InitialDelay = 200;
            this.tltDireccion.IsBalloon = true;
            this.tltDireccion.ReshowDelay = 100;
            this.tltDireccion.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.tltDireccion.ToolTipTitle = "Ingrese Toda la Direccion de Cliente";
            // 
            // lblManteCliente
            // 
            this.lblManteCliente.AutoSize = true;
            this.lblManteCliente.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lblManteCliente.Font = new System.Drawing.Font("Rockwell Condensed", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblManteCliente.Location = new System.Drawing.Point(17, 130);
            this.lblManteCliente.Name = "lblManteCliente";
            this.lblManteCliente.Size = new System.Drawing.Size(189, 29);
            this.lblManteCliente.TabIndex = 20;
            this.lblManteCliente.Text = "Mantenimiento Clientes";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "1\t",
            "0"});
            this.comboBox1.Location = new System.Drawing.Point(132, 476);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 24);
            this.comboBox1.TabIndex = 21;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(132, 265);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(186, 22);
            this.textBox3.TabIndex = 3;
            this.textBox3.Tag = "fecha";
            // 
            // frmCliente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(1410, 638);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.lblManteCliente);
            this.Controls.Add(this.lblDireccionCliente);
            this.Controls.Add(this.lblCorreoCliente);
            this.Controls.Add(this.lblEstado);
            this.Controls.Add(this.lblNumTelefono);
            this.Controls.Add(this.lblApellidoCliente);
            this.Controls.Add(this.lblNombreCliente);
            this.Controls.Add(this.lblFechaNacimiento);
            this.Controls.Add(this.lblNitCliente);
            this.Controls.Add(this.lblCodCliente);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.txtDireccionCliente);
            this.Controls.Add(this.txtCorreoCliente);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.txtNumeroTel);
            this.Controls.Add(this.txtApellidoCliente);
            this.Controls.Add(this.txtNombreCliente);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.txtNitCliente);
            this.Controls.Add(this.txtIdCliente);
            this.Controls.Add(this.navegador1);
            this.MaximizeBox = false;
            this.Name = "frmCliente";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "5101 - Clientes";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private CapaVistaNavegador.Navegador navegador1;
        private System.Windows.Forms.TextBox txtIdCliente;
        private System.Windows.Forms.TextBox txtNitCliente;
        private System.Windows.Forms.TextBox txtApellidoCliente;
        private System.Windows.Forms.TextBox txtNumeroTel;
        private System.Windows.Forms.TextBox txtCorreoCliente;
        private System.Windows.Forms.TextBox txtDireccionCliente;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox txtNombreCliente;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label lblCodCliente;
        private System.Windows.Forms.Label lblNitCliente;
        private System.Windows.Forms.Label lblFechaNacimiento;
        private System.Windows.Forms.Label lblNombreCliente;
        private System.Windows.Forms.Label lblApellidoCliente;
        private System.Windows.Forms.Label lblNumTelefono;
        private System.Windows.Forms.Label lblEstado;
        private System.Windows.Forms.Label lblCorreoCliente;
        private System.Windows.Forms.Label lblDireccionCliente;
        private System.Windows.Forms.ToolTip tltNit;
        private System.Windows.Forms.ToolTip tltCorreo;
        private System.Windows.Forms.ToolTip tltDireccion;
        private System.Windows.Forms.Label lblManteCliente;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox textBox3;
    }
}