﻿using System;
using System.Activities.Expressions;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaControladorCRM;

namespace CapaVistaCRM.Formularios
{
    public partial class frmControlEmpleados : Form
    {
        int idVenta, tot, emp, controlEmpleado, revisar;
        double comisiones, totalcomisiones;
        String idEmp = "";
        String prueba = "";
        DataTable dt = new DataTable();
        public frmControlEmpleados()
        {
            InitializeComponent();
            tltEmpleado.SetToolTip(this.cmbEmpleado, "Ingrese numero de empleado a buscar");
            tltHoras.SetToolTip(this.txtHrExtras, "Ingrese Horas Laboradas durante la jornada");
            tltVenta.SetToolTip(this.txtVenta, "Ingrese el codigo de la venta a buscar");
        }

        private void frmControlEmpleados_Load(object sender, EventArgs e)
        {
            //String prueba="";
            //cmbEmpleado.SelectedValue = prueba;
            //txtCodEmp.Text = prueba;
        }

        clsControladorControlEmpleados cn = new clsControladorControlEmpleados();

        //******************************************* Metodo para el llenado del combobox empleado *************************************
        public void llenarse(string tabla, string campo1, string campo2)
        {

            string tbl = tabla;
            string cmp1 = campo1;
            string cmp2 = campo2;



            /*nombre del cmb*/
            cmbEmpleado.ValueMember = "numero";
            /*nombre del cmb*/
            cmbEmpleado.DisplayMember = "nombre";

            string[] items = cn.items(tabla, campo1, campo2);



            for (int i = 0; i < items.Length; i++)
            {
                if (items[i] != null)
                {
                    if (items[i] != "")
                    {
                        /*nombre del cmb*/
                        cmbEmpleado.Items.Add(items[i]);
                    }
                }

            }

            var dt2 = cn.enviar(tabla, campo1, campo2);
            AutoCompleteStringCollection coleccion = new AutoCompleteStringCollection();
            foreach (DataRow row in dt2.Rows)
            {

                coleccion.Add(Convert.ToString(row[campo1]) + "-" + Convert.ToString(row[campo2]));
                //coleccion.Add(Convert.ToString(row[campo2]) + "-" + Convert.ToString(row[campo1]));


            }

            /*nombre del cmb*/
            cmbEmpleado.AutoCompleteCustomSource = coleccion;
            /*nombre del cmb*/
            cmbEmpleado.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            /*nombre del cmb*/
            cmbEmpleado.AutoCompleteSource = AutoCompleteSource.CustomSource;


        }

        //**************************** Metodo para la revision de ingreso de solo numeros ***************************************
        public static void SoloNumeros(KeyPressEventArgs v)
        {
            if (Char.IsDigit(v.KeyChar))
            {
                v.Handled = false;
            }
            else if (Char.IsSeparator(v.KeyChar))
            {
                v.Handled = false;
            }
            else if (Char.IsControl(v.KeyChar))
            {
                v.Handled = false;
            }
            else
            {
                v.Handled = true;
            }
        }

        private void cmbEmpleado_MouseClick(object sender, MouseEventArgs e)
        {
            //llenarse("empleado", "pk_id_empleado", "nombre1_empleado");
        }

        //********************************** manda a llamar al metodo de llenado para el combobox ********************************
        private void cmbEmpleado_Click(object sender, EventArgs e)
        {
            llenarse("empleado", "pk_id_empleado", "nombre1_empleado");
        }

        //********************************** Realiza la consulta del empleado ingresado y manda el apellido del empleado *****************
        private void btnEmpleado_Click(object sender, EventArgs e)
        {
            emp = Convert.ToInt32(label1.Text.ToString());
            emp = emp + 1;
            idEmp = emp.ToString();

            controlEmpleado = emp - 1;

            clsControladorControlEmpleados cc = new clsControladorControlEmpleados();
            prueba = cc.ControlIdEmp(idEmp);

            txtNomEmp.Text = prueba;
        }

        //********************************** prueba para conocer el valor ingresado en el combobox ************************************
        private void cmbEmpleado_SelectedValueChanged(object sender, EventArgs e)
        {
            prueba = cmbEmpleado.SelectedIndex.ToString();
            label1.Text = prueba;
        }

        private void comboBox1_Click(object sender, EventArgs e)
        {
            
        }

        //************************************************** Metodo para boton de insertar comisiones ******************************
        private void btnInsertar_Click(object sender, EventArgs e)
        {
            if((string.IsNullOrEmpty(txtHrExtras.Text)) || (string.IsNullOrEmpty(txtTotalComisiones.Text)) || (string.IsNullOrEmpty(cmbEmpleado.Text)) || (string.IsNullOrEmpty(txtVenta.Text)))
            {
                MessageBox.Show("No se han completado todos los campos necesarios");
                return;
            }

            prueba = cmbEmpleado.SelectedIndex.ToString();

            clsControladorControlEmpleados con = new clsControladorControlEmpleados();
            con.comisiones(txtHrExtras.Text.ToString(), txtTotalComisiones.Text.ToString(), Convert.ToInt32(txtVenta.Text.ToString()), Convert.ToInt32(prueba.ToString()));
            MessageBox.Show("Registro Exitoso");
            limpiar();

        }

        //********************************** verifica el ingreso de solo numeros **********************************
        private void txtHrExtras_KeyPress(object sender, KeyPressEventArgs e)
        {
            SoloNumeros(e);
        }

        //********************************** agrega la venta y las comisiones al datagriedview ********************************
        private void btnAgregar_Click(object sender, EventArgs e)
        {
            int prueba;
            revisar = Convert.ToInt32(label1.Text.ToString());
            if(revisar != controlEmpleado)
            {
                MessageBox.Show("El usuario se ha cambiado Por Favor Regrese al usuario Seleccionado");
                return;
            }

            if((string.IsNullOrEmpty(txtTotalVenta.Text)) || (string.IsNullOrEmpty(txtVenta.Text)) || (string.IsNullOrEmpty(txtNomEmp.Text)))
            {

                MessageBox.Show("Debe completar la informacion");
                return;

            }
            prueba = Convert.ToInt32(txtTotalVenta.Text.ToString());
            comisiones = Convert.ToInt32(txtTotalVenta.Text.ToString());
            comisiones = comisiones * 0.3;

            emp = Convert.ToInt32(label2.Text.ToString());
            //emp = emp + 1;

            this.dgvControlEmp.Rows.Add(emp, txtTotalVenta.Text, comisiones);
            totalcomisiones = 0;

            foreach (DataGridViewRow row in dgvControlEmp.Rows)
            {
                totalcomisiones += Convert.ToDouble(row.Cells["Column3"].Value);
                txtTotalComisiones.Text = totalcomisiones.ToString();
            }
            //txtTotalComisiones.Text = totalcomisiones.ToString();

        }

        //********************************** limpia todas las casillas **************************************************
        private void button2_Click(object sender, EventArgs e)
        {
            limpiar();
        }

        //********************************** verifica que solo sean ingresados numeros ************************************
        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            SoloNumeros(e);
        }

        public void limpiar()
        {
            txtTotalVenta.Text = "";
            txtVenta.Text = "";
            txtHrExtras.Text = "";
            txtNomEmp.Text = "";
            txtTotalComisiones.Text = "";
            cmbEmpleado.SelectedIndex = -1;
            do
            {
                foreach (DataGridViewRow row in dgvControlEmp.Rows)
                {
                    try
                    {
                        dgvControlEmp.Rows.Remove(row);
                    }
                    catch (Exception) { }
                }
            } while (dgvControlEmp.Rows.Count > 1);
        }

        //********************************** busca la venta ingresada por codigo ************************************
        private void btnBuscarVenta_Click(object sender, EventArgs e)
        {
            idVenta = Convert.ToInt32(txtVenta.Text.ToString());
            label2.Text = idVenta.ToString();

            clsControladorControlEmpleados cc = new clsControladorControlEmpleados();
            tot = Convert.ToInt32(cc.ControlId(idVenta));

            txtTotalVenta.Text = tot.ToString();
        }
    }
}
