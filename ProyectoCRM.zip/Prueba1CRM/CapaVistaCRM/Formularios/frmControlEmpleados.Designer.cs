﻿namespace CapaVistaCRM.Formularios
{
    partial class frmControlEmpleados
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tbcControEmpleado = new System.Windows.Forms.TabControl();
            this.tabInsertar = new System.Windows.Forms.TabPage();
            this.txtHrExtras = new System.Windows.Forms.TextBox();
            this.lblHrExtras = new System.Windows.Forms.Label();
            this.txtTotalComisiones = new System.Windows.Forms.TextBox();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.lblTotalComisiones = new System.Windows.Forms.Label();
            this.btnInsertar = new System.Windows.Forms.Button();
            this.btnAgregar = new System.Windows.Forms.Button();
            this.dgvControlEmp = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cmbEmpleado = new System.Windows.Forms.ComboBox();
            this.btnEmpleado = new System.Windows.Forms.Button();
            this.txtNomEmp = new System.Windows.Forms.TextBox();
            this.lblNomEmpleado = new System.Windows.Forms.Label();
            this.lblCodEmp = new System.Windows.Forms.Label();
            this.gbxBuscarVenta = new System.Windows.Forms.GroupBox();
            this.txtVenta = new System.Windows.Forms.TextBox();
            this.lblTotalVenta = new System.Windows.Forms.Label();
            this.txtTotalVenta = new System.Windows.Forms.TextBox();
            this.btnBuscarVenta = new System.Windows.Forms.Button();
            this.lblCodVenta = new System.Windows.Forms.Label();
            this.lblControl = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnAyuda = new System.Windows.Forms.Button();
            this.tltEmpleado = new System.Windows.Forms.ToolTip(this.components);
            this.tltVenta = new System.Windows.Forms.ToolTip(this.components);
            this.tltHoras = new System.Windows.Forms.ToolTip(this.components);
            this.tbcControEmpleado.SuspendLayout();
            this.tabInsertar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvControlEmp)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.gbxBuscarVenta.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbcControEmpleado
            // 
            this.tbcControEmpleado.Controls.Add(this.tabInsertar);
            this.tbcControEmpleado.Font = new System.Drawing.Font("Rockwell Condensed", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbcControEmpleado.Location = new System.Drawing.Point(12, 62);
            this.tbcControEmpleado.Name = "tbcControEmpleado";
            this.tbcControEmpleado.SelectedIndex = 0;
            this.tbcControEmpleado.Size = new System.Drawing.Size(1304, 547);
            this.tbcControEmpleado.TabIndex = 1;
            // 
            // tabInsertar
            // 
            this.tabInsertar.BackColor = System.Drawing.Color.Silver;
            this.tabInsertar.Controls.Add(this.txtHrExtras);
            this.tabInsertar.Controls.Add(this.lblHrExtras);
            this.tabInsertar.Controls.Add(this.txtTotalComisiones);
            this.tabInsertar.Controls.Add(this.btnLimpiar);
            this.tabInsertar.Controls.Add(this.lblTotalComisiones);
            this.tabInsertar.Controls.Add(this.btnInsertar);
            this.tabInsertar.Controls.Add(this.btnAgregar);
            this.tabInsertar.Controls.Add(this.dgvControlEmp);
            this.tabInsertar.Controls.Add(this.groupBox1);
            this.tabInsertar.Controls.Add(this.gbxBuscarVenta);
            this.tabInsertar.Location = new System.Drawing.Point(4, 29);
            this.tabInsertar.Name = "tabInsertar";
            this.tabInsertar.Padding = new System.Windows.Forms.Padding(3);
            this.tabInsertar.Size = new System.Drawing.Size(1296, 514);
            this.tabInsertar.TabIndex = 0;
            this.tabInsertar.Text = "Insertar Control Empleado";
            this.tabInsertar.ToolTipText = "Insercion de Comisiones por Empleado";
            // 
            // txtHrExtras
            // 
            this.txtHrExtras.Location = new System.Drawing.Point(156, 268);
            this.txtHrExtras.Name = "txtHrExtras";
            this.txtHrExtras.Size = new System.Drawing.Size(100, 27);
            this.txtHrExtras.TabIndex = 10;
            this.txtHrExtras.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtHrExtras_KeyPress);
            // 
            // lblHrExtras
            // 
            this.lblHrExtras.AutoSize = true;
            this.lblHrExtras.Location = new System.Drawing.Point(48, 273);
            this.lblHrExtras.Name = "lblHrExtras";
            this.lblHrExtras.Size = new System.Drawing.Size(102, 20);
            this.lblHrExtras.TabIndex = 9;
            this.lblHrExtras.Text = "Horas Trabajadas";
            // 
            // txtTotalComisiones
            // 
            this.txtTotalComisiones.Enabled = false;
            this.txtTotalComisiones.Location = new System.Drawing.Point(231, 470);
            this.txtTotalComisiones.Name = "txtTotalComisiones";
            this.txtTotalComisiones.Size = new System.Drawing.Size(135, 27);
            this.txtTotalComisiones.TabIndex = 8;
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.Image = global::CapaVistaCRM.Properties.Resources.logo_orange_ccleaner_clean_icon_1343651;
            this.btnLimpiar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLimpiar.Location = new System.Drawing.Point(1191, 473);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(90, 34);
            this.btnLimpiar.TabIndex = 7;
            this.btnLimpiar.Text = "Limpiar";
            this.btnLimpiar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnLimpiar.UseVisualStyleBackColor = true;
            this.btnLimpiar.Click += new System.EventHandler(this.button2_Click);
            // 
            // lblTotalComisiones
            // 
            this.lblTotalComisiones.AutoSize = true;
            this.lblTotalComisiones.Font = new System.Drawing.Font("Rockwell Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalComisiones.Location = new System.Drawing.Point(107, 470);
            this.lblTotalComisiones.Name = "lblTotalComisiones";
            this.lblTotalComisiones.Size = new System.Drawing.Size(118, 24);
            this.lblTotalComisiones.TabIndex = 6;
            this.lblTotalComisiones.Text = "Total Comisiones";
            // 
            // btnInsertar
            // 
            this.btnInsertar.Image = global::CapaVistaCRM.Properties.Resources.construction_project_plan_building_architect_design_develop_73_icon_icons_com_60243;
            this.btnInsertar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnInsertar.Location = new System.Drawing.Point(828, 473);
            this.btnInsertar.Name = "btnInsertar";
            this.btnInsertar.Size = new System.Drawing.Size(145, 35);
            this.btnInsertar.TabIndex = 5;
            this.btnInsertar.Text = "Insertar Comision";
            this.btnInsertar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnInsertar.UseVisualStyleBackColor = true;
            this.btnInsertar.Click += new System.EventHandler(this.btnInsertar_Click);
            // 
            // btnAgregar
            // 
            this.btnAgregar.Image = global::CapaVistaCRM.Properties.Resources.businesspackage_additionalpackage_box_add_insert_negoci_2335;
            this.btnAgregar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAgregar.Location = new System.Drawing.Point(875, 268);
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(125, 30);
            this.btnAgregar.TabIndex = 3;
            this.btnAgregar.Text = "Agregar Venta";
            this.btnAgregar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAgregar.UseVisualStyleBackColor = true;
            this.btnAgregar.Click += new System.EventHandler(this.btnAgregar_Click);
            // 
            // dgvControlEmp
            // 
            this.dgvControlEmp.AllowUserToDeleteRows = false;
            this.dgvControlEmp.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvControlEmp.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3});
            this.dgvControlEmp.Location = new System.Drawing.Point(22, 304);
            this.dgvControlEmp.Name = "dgvControlEmp";
            this.dgvControlEmp.ReadOnly = true;
            this.dgvControlEmp.RowHeadersWidth = 51;
            this.dgvControlEmp.RowTemplate.Height = 24;
            this.dgvControlEmp.Size = new System.Drawing.Size(1260, 150);
            this.dgvControlEmp.TabIndex = 2;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "ID Venta";
            this.Column1.MinimumWidth = 6;
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 125;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Total Venta";
            this.Column2.MinimumWidth = 6;
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 125;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Comisiones Por Venta";
            this.Column3.MinimumWidth = 6;
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.Width = 125;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cmbEmpleado);
            this.groupBox1.Controls.Add(this.btnEmpleado);
            this.groupBox1.Controls.Add(this.txtNomEmp);
            this.groupBox1.Controls.Add(this.lblNomEmpleado);
            this.groupBox1.Controls.Add(this.lblCodEmp);
            this.groupBox1.Location = new System.Drawing.Point(22, 19);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1250, 100);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Agregar Empleado";
            // 
            // cmbEmpleado
            // 
            this.cmbEmpleado.FormattingEnabled = true;
            this.cmbEmpleado.Location = new System.Drawing.Point(153, 43);
            this.cmbEmpleado.Name = "cmbEmpleado";
            this.cmbEmpleado.Size = new System.Drawing.Size(147, 28);
            this.cmbEmpleado.TabIndex = 5;
            this.cmbEmpleado.SelectedValueChanged += new System.EventHandler(this.cmbEmpleado_SelectedValueChanged);
            this.cmbEmpleado.Click += new System.EventHandler(this.cmbEmpleado_Click);
            this.cmbEmpleado.MouseClick += new System.Windows.Forms.MouseEventHandler(this.cmbEmpleado_MouseClick);
            // 
            // btnEmpleado
            // 
            this.btnEmpleado.Image = global::CapaVistaCRM.Properties.Resources.find_users_applications_search_2908;
            this.btnEmpleado.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEmpleado.Location = new System.Drawing.Point(318, 43);
            this.btnEmpleado.Name = "btnEmpleado";
            this.btnEmpleado.Size = new System.Drawing.Size(193, 40);
            this.btnEmpleado.TabIndex = 4;
            this.btnEmpleado.Text = "Seleccionar Empleado";
            this.btnEmpleado.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEmpleado.UseVisualStyleBackColor = true;
            this.btnEmpleado.Click += new System.EventHandler(this.btnEmpleado_Click);
            // 
            // txtNomEmp
            // 
            this.txtNomEmp.Enabled = false;
            this.txtNomEmp.Location = new System.Drawing.Point(952, 42);
            this.txtNomEmp.Name = "txtNomEmp";
            this.txtNomEmp.Size = new System.Drawing.Size(139, 27);
            this.txtNomEmp.TabIndex = 3;
            // 
            // lblNomEmpleado
            // 
            this.lblNomEmpleado.AutoSize = true;
            this.lblNomEmpleado.Font = new System.Drawing.Font("Rockwell Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomEmpleado.Location = new System.Drawing.Point(802, 42);
            this.lblNomEmpleado.Name = "lblNomEmpleado";
            this.lblNomEmpleado.Size = new System.Drawing.Size(129, 24);
            this.lblNomEmpleado.TabIndex = 2;
            this.lblNomEmpleado.Text = "Apellido Empleado";
            // 
            // lblCodEmp
            // 
            this.lblCodEmp.AutoSize = true;
            this.lblCodEmp.Font = new System.Drawing.Font("Rockwell Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCodEmp.Location = new System.Drawing.Point(26, 42);
            this.lblCodEmp.Name = "lblCodEmp";
            this.lblCodEmp.Size = new System.Drawing.Size(120, 24);
            this.lblCodEmp.TabIndex = 0;
            this.lblCodEmp.Text = "Codigo Empleado";
            // 
            // gbxBuscarVenta
            // 
            this.gbxBuscarVenta.Controls.Add(this.txtVenta);
            this.gbxBuscarVenta.Controls.Add(this.lblTotalVenta);
            this.gbxBuscarVenta.Controls.Add(this.txtTotalVenta);
            this.gbxBuscarVenta.Controls.Add(this.btnBuscarVenta);
            this.gbxBuscarVenta.Controls.Add(this.lblCodVenta);
            this.gbxBuscarVenta.Location = new System.Drawing.Point(22, 153);
            this.gbxBuscarVenta.Name = "gbxBuscarVenta";
            this.gbxBuscarVenta.Size = new System.Drawing.Size(1250, 109);
            this.gbxBuscarVenta.TabIndex = 0;
            this.gbxBuscarVenta.TabStop = false;
            this.gbxBuscarVenta.Text = "Busqueda de Venta";
            // 
            // txtVenta
            // 
            this.txtVenta.Location = new System.Drawing.Point(153, 48);
            this.txtVenta.Name = "txtVenta";
            this.txtVenta.Size = new System.Drawing.Size(147, 27);
            this.txtVenta.TabIndex = 5;
            this.txtVenta.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // lblTotalVenta
            // 
            this.lblTotalVenta.AutoSize = true;
            this.lblTotalVenta.Font = new System.Drawing.Font("Rockwell Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalVenta.Location = new System.Drawing.Point(802, 48);
            this.lblTotalVenta.Name = "lblTotalVenta";
            this.lblTotalVenta.Size = new System.Drawing.Size(87, 24);
            this.lblTotalVenta.TabIndex = 4;
            this.lblTotalVenta.Text = "Total Venta";
            // 
            // txtTotalVenta
            // 
            this.txtTotalVenta.Enabled = false;
            this.txtTotalVenta.Location = new System.Drawing.Point(952, 45);
            this.txtTotalVenta.Name = "txtTotalVenta";
            this.txtTotalVenta.Size = new System.Drawing.Size(139, 27);
            this.txtTotalVenta.TabIndex = 3;
            // 
            // btnBuscarVenta
            // 
            this.btnBuscarVenta.Image = global::CapaVistaCRM.Properties.Resources.shoppingcart_77968;
            this.btnBuscarVenta.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBuscarVenta.Location = new System.Drawing.Point(318, 46);
            this.btnBuscarVenta.Name = "btnBuscarVenta";
            this.btnBuscarVenta.Size = new System.Drawing.Size(146, 29);
            this.btnBuscarVenta.TabIndex = 2;
            this.btnBuscarVenta.Text = "Buscar Venta";
            this.btnBuscarVenta.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBuscarVenta.UseVisualStyleBackColor = true;
            this.btnBuscarVenta.Click += new System.EventHandler(this.btnBuscarVenta_Click);
            // 
            // lblCodVenta
            // 
            this.lblCodVenta.AutoSize = true;
            this.lblCodVenta.Font = new System.Drawing.Font("Rockwell Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCodVenta.Location = new System.Drawing.Point(22, 48);
            this.lblCodVenta.Name = "lblCodVenta";
            this.lblCodVenta.Size = new System.Drawing.Size(118, 24);
            this.lblCodVenta.TabIndex = 0;
            this.lblCodVenta.Text = "Codigo de Venta";
            // 
            // lblControl
            // 
            this.lblControl.AutoSize = true;
            this.lblControl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lblControl.Font = new System.Drawing.Font("Rockwell Condensed", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblControl.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblControl.Location = new System.Drawing.Point(13, 8);
            this.lblControl.Name = "lblControl";
            this.lblControl.Size = new System.Drawing.Size(212, 29);
            this.lblControl.TabIndex = 2;
            this.lblControl.Text = "Control Empleados Ventas";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(433, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 17);
            this.label1.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(558, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 17);
            this.label2.TabIndex = 4;
            // 
            // btnAyuda
            // 
            this.btnAyuda.Image = global::CapaVistaCRM.Properties.Resources.search_locate_find_icon_icons_com_67287;
            this.btnAyuda.Location = new System.Drawing.Point(1250, 8);
            this.btnAyuda.Name = "btnAyuda";
            this.btnAyuda.Size = new System.Drawing.Size(62, 48);
            this.btnAyuda.TabIndex = 0;
            this.btnAyuda.UseVisualStyleBackColor = true;
            // 
            // tltEmpleado
            // 
            this.tltEmpleado.AutoPopDelay = 5000;
            this.tltEmpleado.InitialDelay = 200;
            this.tltEmpleado.IsBalloon = true;
            this.tltEmpleado.ReshowDelay = 100;
            this.tltEmpleado.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.tltEmpleado.ToolTipTitle = "Seleccione Empleado";
            // 
            // tltVenta
            // 
            this.tltVenta.AutoPopDelay = 5000;
            this.tltVenta.InitialDelay = 200;
            this.tltVenta.IsBalloon = true;
            this.tltVenta.ReshowDelay = 100;
            this.tltVenta.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.tltVenta.ToolTipTitle = "Seleccione Codigo de venta";
            // 
            // tltHoras
            // 
            this.tltHoras.AutoPopDelay = 5000;
            this.tltHoras.InitialDelay = 200;
            this.tltHoras.IsBalloon = true;
            this.tltHoras.ReshowDelay = 100;
            this.tltHoras.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.tltHoras.ToolTipTitle = "Ingrese Horas Trabajadas en el Mes";
            // 
            // frmControlEmpleados
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(1328, 621);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblControl);
            this.Controls.Add(this.tbcControEmpleado);
            this.Controls.Add(this.btnAyuda);
            this.MaximizeBox = false;
            this.Name = "frmControlEmpleados";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "5001 - Control Empleados Ventas";
            this.Load += new System.EventHandler(this.frmControlEmpleados_Load);
            this.tbcControEmpleado.ResumeLayout(false);
            this.tabInsertar.ResumeLayout(false);
            this.tabInsertar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvControlEmp)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.gbxBuscarVenta.ResumeLayout(false);
            this.gbxBuscarVenta.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAyuda;
        private System.Windows.Forms.TabControl tbcControEmpleado;
        private System.Windows.Forms.TabPage tabInsertar;
        private System.Windows.Forms.Label lblControl;
        private System.Windows.Forms.GroupBox gbxBuscarVenta;
        private System.Windows.Forms.Button btnBuscarVenta;
        private System.Windows.Forms.Label lblCodVenta;
        private System.Windows.Forms.Button btnAgregar;
        private System.Windows.Forms.DataGridView dgvControlEmp;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnEmpleado;
        private System.Windows.Forms.TextBox txtNomEmp;
        private System.Windows.Forms.Label lblNomEmpleado;
        private System.Windows.Forms.Label lblCodEmp;
        private System.Windows.Forms.Label lblTotalVenta;
        private System.Windows.Forms.TextBox txtTotalVenta;
        private System.Windows.Forms.TextBox txtTotalComisiones;
        private System.Windows.Forms.Button btnLimpiar;
        private System.Windows.Forms.Label lblTotalComisiones;
        private System.Windows.Forms.Button btnInsertar;
        private System.Windows.Forms.ComboBox cmbEmpleado;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtVenta;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtHrExtras;
        private System.Windows.Forms.Label lblHrExtras;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.ToolTip tltEmpleado;
        private System.Windows.Forms.ToolTip tltVenta;
        private System.Windows.Forms.ToolTip tltHoras;
    }
}