﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Odbc;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaModeloCRM
{
    public class clsModeloPedido
    {
        ///Modelo///
        clsConexion con = new clsConexion();

        int totalVenta, idemp, idPedido, idprod;
        String apellido = "";
        // ----------------------------------------   Llenado de Combobox de Producto ----------------------------------------
        public string[] llenarCmb(string tabla, string campo1, string campo2)
        {

            string[] Campos = new string[300];
            string[] auto = new string[300];
            int i = 0;
            string sql = "SELECT " + campo1 + "," + campo2 + " FROM " + tabla + " where estado_producto = 1 ;";

            try
            {
                OdbcCommand command = new OdbcCommand(sql, con.conexion());
                OdbcDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {

                    Campos[i] = reader.GetValue(0).ToString() + "-" + reader.GetValue(1).ToString();
                    i++;
                }
            }
            catch (Exception ex) { Console.WriteLine(ex.Message.ToString() + " \nError en asignarCombo, revise los parametros \n -" + tabla + "\n -" + campo1); }


            return Campos;
        }

        public DataTable obtener(string tabla, string campo1, string campo2)
        {

            string sql = "SELECT " + campo1 + "," + campo2 + " FROM " + tabla + " where estado_producto = 1  ;";

            OdbcCommand command = new OdbcCommand(sql, con.conexion());
            OdbcDataAdapter adaptador = new OdbcDataAdapter(command);
            DataTable dt = new DataTable();
            adaptador.Fill(dt);
            return dt;
        }

        //----------------------------------------------------- Llenado de Combobox de Fabrica ----------------------------------------------
        public string[] llenarCmbFabrica(string tabla, string campo1, string campo2)
        {

            string[] Campos = new string[300];
            string[] auto = new string[300];
            int i = 0;
            string sql = "SELECT " + campo1 + "," + campo2 + " FROM " + tabla + " where estado_fabrica = 1 ;";

            try
            {
                OdbcCommand command = new OdbcCommand(sql, con.conexion());
                OdbcDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {

                    Campos[i] = reader.GetValue(0).ToString() + "-" + reader.GetValue(1).ToString();
                    i++;
                }
            }
            catch (Exception ex) { Console.WriteLine(ex.Message.ToString() + " \nError en asignarCombo, revise los parametros \n -" + tabla + "\n -" + campo1); }


            return Campos;
        }

        public DataTable obtenerFabrica(string tabla, string campo1, string campo2)
        {

            string sql = "SELECT " + campo1 + "," + campo2 + " FROM " + tabla + " where estado_fabrica = 1  ;";

            OdbcCommand command = new OdbcCommand(sql, con.conexion());
            OdbcDataAdapter adaptador = new OdbcDataAdapter(command);
            DataTable dt = new DataTable();
            adaptador.Fill(dt);
            return dt;
        }

        //********************************** Metodo Para insertar en encabezado pedido ****************************************
        public void insertarPedido(int fabrica, string fecha, double total)
        {
            int num1 = 1;
            int num2 = 1;
            int num3 = 3;
            try
            {
                string sql = "SELECT pk_id_pedido_encabezado FROM pedido_encabezado ORDER BY pk_id_pedido_encabezado DESC LIMIT 1";
                OdbcCommand command = new OdbcCommand(sql, con.conexion());
                OdbcDataReader read;
                read = command.ExecuteReader();
                while (read.Read())
                {
                    apellido = read.GetString(0);
                }

                idPedido = Convert.ToInt32(apellido.ToString());
                idPedido = idPedido + 1;

                DateTime fech = DateTime.Now;
                string fechaSalida4 = fech.ToString("yyyy/mm/dd HH:mm");
                fabrica = fabrica + 1;

                string sql1 = "insert into pedido_encabezado values (" + idPedido + ", " + fabrica + ", "+num1+", '" + fechaSalida4 + "', "+total+", "+num2+");";
                OdbcCommand command1 = new OdbcCommand(sql1, con.conexion());
                command1.ExecuteNonQuery();
            }
            catch
            {
                Console.WriteLine("No Conectó");
            }
        }

        //*************************************************** Insertar productos de pedidos *************************************
        public void insertarDetallePedido(int id, int cant, double precio, double subtotal)
        {
            int num = 1;
            int num2 = 1;
            try
            {
                string sql = "SELECT pk_id_pedido_encabezado FROM pedido_encabezado ORDER BY pk_id_pedido_encabezado DESC LIMIT 1";
                OdbcCommand command = new OdbcCommand(sql, con.conexion());
                OdbcDataReader read;
                read = command.ExecuteReader();
                while (read.Read())
                {
                    apellido = read.GetString(0);
                }

                idprod = Convert.ToInt32(apellido.ToString());

                string sql1 = "INSERT INTO pedido_detalle VALUES (" + idprod + ", " + num + ", " + id + ", '" + cant + "', " + precio + ", " + subtotal + ", "+ num2 +");";
                OdbcCommand command1 = new OdbcCommand(sql1, con.conexion());
                command1.ExecuteNonQuery();

            }
            catch
            {

            }
        }

    }
}
