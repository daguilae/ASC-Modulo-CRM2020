﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Odbc;

namespace CapaModeloCRM
{
    public class clsModeloControlEmpleados
    {
        ///Modelo///
        clsConexion con = new clsConexion();

        int totalVenta, idemp;
        String apellido="";

        //********************************** metodos para la consulta y llenado del combobox de empleado **************************
        public string[] llenarCmb(string tabla, string campo1, string campo2)
        {

            string[] Campos = new string[300];
            string[] auto = new string[300];
            int i = 0;
            string sql = "SELECT " + campo1 + "," + campo2 + " FROM " + tabla + " where estado_empleado = 1 ;";

            try
            {
                OdbcCommand command = new OdbcCommand(sql, con.conexion());
                OdbcDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {

                    Campos[i] = reader.GetValue(0).ToString() + "-" + reader.GetValue(1).ToString();
                    i++;
                }
            }
            catch (Exception ex) { Console.WriteLine(ex.Message.ToString() + " \nError en asignarCombo, revise los parametros \n -" + tabla + "\n -" + campo1); }


            return Campos;
        }

        public DataTable obtener(string tabla, string campo1, string campo2)
        {

            string sql = "SELECT " + campo1 + "," + campo2 + " FROM " + tabla + " where estado_empleado = 1  ;";

            OdbcCommand command = new OdbcCommand(sql, con.conexion());
            OdbcDataAdapter adaptador = new OdbcDataAdapter(command);
            DataTable dt = new DataTable();
            adaptador.Fill(dt);


            return dt;
        }

        //********************************** consulta para conocer el total de la venta ingresada *************************************
        public int ventas(int result)
        {
            string sql = "SELECT total_factura FROM facturas where pk_id_factura = " + result + ";";

            OdbcCommand command = new OdbcCommand(sql, con.conexion());
            OdbcDataReader read;
            read = command.ExecuteReader();

            while (read.Read())
            {
                totalVenta = read.GetInt32(0);
            }

            //totalVenta = Convert.ToInt32(read);

            return totalVenta;          
        }

        //********************************** metodo para devolver el apellido del empleado ingresado *******************************
        public string empleado(string result)
        {
            idemp = Convert.ToInt32(result.ToString());

            string sql = "SELECT apellido2_empleado FROM empleado where pk_id_empleado = " + idemp + ";";

            OdbcCommand command = new OdbcCommand(sql, con.conexion());
            OdbcDataReader read;
            read = command.ExecuteReader();

            while (read.Read())
            {
                apellido = read.GetString(0);
            }

            return apellido;
        }

        //************************************** Metodo para insertar comisiones en base de datos *************************************
        public void insertarComisiones(string hrs, string comi, int vent, int emp)
        {
            try
            {
                emp = emp + 1;
                string sql = "insert into control_empleado (horas_extras_de_trabajo, comisiones_ventas, fk_id_venta, fk_id_empleado) values ('" + hrs + "', '" + comi + "', " + vent + ", " + emp + ");";
                OdbcCommand command = new OdbcCommand(sql, con.conexion());
                command.ExecuteNonQuery();

            }
            catch
            {

            }
        }

    }
}
